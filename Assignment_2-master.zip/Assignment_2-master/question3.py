number1=int(input("enter value of x"))
number2=int(input("enter value of y"))
number3=int(input("enter value of z"))
print("user has enterd the values of x,y and z",number1,number2,number3)