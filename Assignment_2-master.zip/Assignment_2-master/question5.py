s= input("acadview")
course=input("python")
fees=int(input("5000"))
print(('%s''%s''%d')%(s,course,fees))


