name= input("tony stark")
salary=input(1000000)
print(('%s''%d')%(name,salary))